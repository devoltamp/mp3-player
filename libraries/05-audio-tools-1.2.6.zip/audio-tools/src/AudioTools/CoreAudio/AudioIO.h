#pragma once
#include "AudioTools/CoreAudio/AudioOutput.h"
#include "AudioTools/CoreAudio/AudioStreams.h"
#include "AudioTools/Communication/HTTP/AudioClient.h"  // for Client

#ifndef MAX_ZERO_READ_COUNT
#define MAX_ZERO_READ_COUNT 3
#endif

#ifndef CHANNEL_SELECT_BUFFER_SIZE
#define CHANNEL_SELECT_BUFFER_SIZE 256
#endif

namespace audio_tools {
/**
 * @brief ConverterStream Helper class which implements the
 *  readBytes with the help of write.
 * @author Phil Schatzmann
 * @copyright GPLv3
 * @tparam T class name of the original transformer stream
 */
template <class T>
class TransformationReader {
 public:
  /// @brief setup of the TransformationReader class
  /// @param transform The original transformer stream
  /// @param source The data source of the data to be converted
  /// the requested converted bytes
  void begin(T* transform, Stream* source) {
    TRACED();
    active = true;
    is_eof = false;
    total_bytes_read = 0;
    last_setup_buffer_size = 0;
    p_stream = source;
    p_transform = transform;
    if (transform == nullptr) {
      LOGE("transform is NULL");
      active = false;
    }
    if (p_stream == nullptr) {
      LOGE("p_stream is NULL");
      active = false;
    }
  }

  size_t readBytes(uint8_t* data, size_t len) {
    LOGD("TransformationReader::readBytes: %d", (int)len);
    if (!active) {
      LOGE("inactive");
      return 0;
    }
    if (p_stream == nullptr) {
      LOGE("p_stream is NULL");
      return 0;
    }

    setupBuffers(len);

    if (!is_eof) {
      fillResultQueue(len);
    }

    int result_len = min((int)len, result_queue.available());
    result_len = result_queue.readBytes(data, result_len);
    LOGD("TransformationReader::readBytes: %d -> %d", (int)len, result_len);
    total_bytes_read += result_len;
    return result_len;
  }

  /// Fills the internal queue up to at least DEFAULT_BUFFER_SIZE bytes (if possible) and
  /// reports the currently available queue size limited by max_read_size.
  int available() {
    if (!active || p_stream == nullptr || p_transform == nullptr) return 0;
    if (is_eof) return result_queue.available();
    setupBuffers(max_read_size);
    fillResultQueue(max_read_size);
    int available_bytes = result_queue.available();
    LOGD("TransformationReader::available: %d", available_bytes);
    return available_bytes > max_read_size ? max_read_size : available_bytes;
  }

  void end() {
    result_queue_buffer.resize(0);
    buffer.resize(0);
    total_bytes_read = 0;
    active = false;
  }

  /// Defines the queue size dependent on the read size
  void setResultQueueFactor(int factor) { result_queue_factor = factor; }

  /// Defines the queue size for result
  void resizeResultQueue(int size) {
    result_queue_buffer.resize(size);
    result_queue.begin();
  }

  void setMaxReadSize(int size) { max_read_size = size; }

  size_t getTotalBytesRead() const { return total_bytes_read; }

  /// Defines how a run of MAX_ZERO_READ_COUNT consecutive empty reads from
  /// the source is interpreted:
  /// - true (default): the source is treated as finished (e.g. end of file)
  ///   and is_eof latches permanently - matches the historical behavior for
  ///   decoders/encoders reading a finite stream.
  /// - false: the source is treated as a live/continuous producer that is
  ///   just momentarily empty (a buffer underflow). is_eof is never set, so
  ///   the next call simply tries again once more data has arrived.
  void setEofOnZeroReads(bool flag) { eof_on_zero_reads = flag; }

  /// Defines how long fillResultQueue() blocks in delay() after each empty
  /// read from the source, before retrying (up to MAX_ZERO_READ_COUNT
  /// times). Default is 5ms, matching historical behavior. For a live
  /// producer read from the same thread/task that also has to keep some
  /// other time-critical consumer fed (e.g. an I2S output pump driven from
  /// the same loop()), blocking here for up to MAX_ZERO_READ_COUNT * this
  /// value on every transient underflow can itself starve that consumer -
  /// set this to 0 in that case so a momentarily-empty source just returns
  /// immediately with whatever's available instead of stalling the caller.
  void setZeroReadDelay(uint32_t delay_ms) { zero_read_delay_ms = delay_ms; }

 protected:
  RingBuffer<uint8_t> result_queue_buffer{0};
  QueueStream<uint8_t> result_queue{result_queue_buffer};  //
  Stream* p_stream = nullptr;
  Vector<uint8_t> buffer{0};  // we allocate memory only when needed
  T* p_transform = nullptr;
  bool active = false;
  int result_queue_factor = 5;
  int max_read_size = DEFAULT_BUFFER_SIZE;
  int last_setup_buffer_size = 0;
  float last_byte_factor = 0.0f;
  bool is_eof = false;
  bool eof_on_zero_reads = true;
  uint32_t zero_read_delay_ms = 5;
  size_t total_bytes_read = 0;

  /// Defines the read buffer size for individual reads
  void resizeReadBuffer(int size) { buffer.resize(size); }

  void setupBuffers(size_t len) {
    float byte_factor = p_transform->getByteFactor();
    if (byte_factor <= 0.0f) {
      LOGE("Invalid byte factor: %f", byte_factor);
      byte_factor = 1.0f;
    }
    // Recompute if the requested length changed, or if the transform's byte
    // factor drifted meaningfully since the read chunk size was last sized
    // (e.g. a live-adjusted resampling step size). For a transform with a
    // constant byte factor (the common decoder/encoder case) this check
    // never re-triggers after the first call, so behavior there is
    // unchanged; it only matters for transforms whose byte factor changes
    // at runtime, where a stale chunk size would otherwise silently distort
    // the consumption/production ratio.
    bool byte_factor_changed =
        fabsf(byte_factor - last_byte_factor) > 0.01f * last_byte_factor;
    if (len == last_setup_buffer_size && !byte_factor_changed) return;
    LOGD("setupBuffers: %d", (int)len);
    last_byte_factor = byte_factor;

    // we read half the necessary bytes
    int size = (0.5f / byte_factor * len);
    // process full samples/frames
    size = size / 4 * 4;
    if (size <= 0) size = 4;
    if (buffer.size() < size) {
      LOGI("read size: %d", size);
      buffer.resize(size);
    }

    if (result_queue_buffer.size() == 0) {
      // make sure that the ring buffer is big enough
      int rb_size = len * result_queue_factor;
      LOGI("buffer size: %d", rb_size);
      result_queue_buffer.resize(rb_size);
      result_queue.begin();
    }
    last_setup_buffer_size = len;
  }

  /// Fills the result queue until at least len bytes are available or no more
  /// input data arrives.
  void fillResultQueue(size_t len) {
    if (is_eof) return;
    if (result_queue.available() >= len) return;
    LOGD("fillResultQueue: %d", (int)len);

    // Detect misconfigured buffer: if the ring buffer capacity is smaller than
    // the requested len bytes we can never satisfy the condition and will loop
    // forever. Issue an error and bail out early.
    if ((int)len > result_queue_buffer.size()) {
      LOGE("fillResultQueue: result_queue_buffer too small: %d < %d. "
           "Increase result_queue_factor or call resizeReadResultQueue().",
           result_queue_buffer.size(), (int)len);
      return;
    }

    Print* tmp = setupOutput();
    int zero_count = 0;
    while (result_queue.available() < len) {
      // Detect buffer-full stall: if we can't write any more data but the
      // queue is still below len, we must stop to avoid an endless loop.
      if (result_queue.available() >= result_queue_buffer.size()) {
        LOGE("fillResultQueue: result_queue full (%d) but target not reached "
             "(%d/%d). Increase result_queue_factor or call "
             "resizeReadResultQueue().",
             result_queue_buffer.size(), result_queue.available(), (int)len);
        break;
      }
      int read_size = buffer.size();
      int read_eff = p_stream->readBytes(buffer.data(), read_size);
      LOGD("readBytes from source: %d -> %d", read_size,read_eff);
      if (read_eff > 0) {
        zero_count = 0;  // reset 0 count
        if (read_eff != buffer.size()) {
          LOGD("readBytes %d -> %d", buffer.size(), read_eff);
        }
        int write_eff = p_transform->write(buffer.data(), read_eff);
        if (write_eff != read_eff) {
          LOGE("TransformationReader::write %d -> %d", read_eff, write_eff);
        }
      } else {
        // limit the number of reads which provide 0;
        if (++zero_count > MAX_ZERO_READ_COUNT) {
          if (eof_on_zero_reads) {
            is_eof = true;
            // Flush any buffered/final encoder bytes into result_queue.
            p_transform->flush();
          }
          // Otherwise the source is just a momentarily empty live
          // producer (buffer underflow, not end of stream): stop trying
          // for this call, but leave is_eof false so the next call
          // retries once more data has arrived.
          break;
        }
        // wait for some more data
        if (zero_read_delay_ms > 0) delay(zero_read_delay_ms);
      }
    }
    LOGD("fillResultQueue available: %d", result_queue.available());
    restoreOutput(tmp);
  }

  /// Makes sure that the data  is written to the array
  /// @param data
  /// @return original output of the converter class
  Print* setupOutput() {
    Print* result = p_transform->getPrint();
    p_transform->setOutput((Print&)result_queue);

    return result;
  }
  /// @brief  restores the original output in the converter class
  /// @param out
  void restoreOutput(Print* out) {
    if (out) p_transform->setOutput(*out);
  }
};

/**
 * @brief Base class for chained converting streams
 * @author Phil Schatzmann
 * @copyright GPLv3
 *
 */
class ReformatBaseStream : public ModifyingStream {
 public:
  virtual void setStream(Stream& stream) override {
    TRACED();
    p_io = &stream;
    p_out = &stream;
  }

  virtual void setStream(AudioStream& stream) {
    TRACED();
    p_io = &stream;
    p_out = &stream;
    // setNotifyOnOutput(stream);
    addNotifyAudioChange(stream);
  }

  virtual void setOutput(AudioOutput& print) {
    TRACED();
    p_out = &print;
    addNotifyAudioChange(print);
  }

  virtual void setOutput(Print& print) override {
    TRACED();
    p_out = &print;
  }

  virtual Print* getPrint() { return p_out; }

  virtual Stream* getStream() { return p_io; }

  size_t readBytes(uint8_t* data, size_t len) override {
    LOGD("ReformatBaseStream::readBytes: %d", (int)len);
    return reader.readBytes(data, len);
  }

  int available() override {
    return reader.available();
  }

  int availableForWrite() override {
    return DEFAULT_BUFFER_SIZE;  // reader.availableForWrite();
  }

  virtual float getByteFactor() = 0;

  /// Called by TransformationReader when EOF is detected on the source stream.
  /// Override in subclasses to flush any internally buffered encoder/decoder
  /// data into the current output (which at that point is the result_queue).
  /// Do NOT call the full end()/begin() cycle here – that would destroy the
  /// reader's own buffers and reset the is_eof flag.
  virtual void flush() {}

  void end() override {
    TRACED();
    AudioStream::end();
    reader.end();
  }

  /// Define the size of the interal read result queue: same as
  /// transformationReader().resizeResultQueue(size)
  void resizeReadResultQueue(int size) { reader.resizeResultQueue(size); }

  /// same as resizeReadResultQueue(size)
  void setReadResultQueueSize(int size) { reader.resizeResultQueue(size); }

  /// Defines the read buffer size for individual reads: same as transformationReader().setMaxReadSize(size)
  void setMaxReadSize(int size) { reader.setMaxReadSize(size); }

  /// Provides access to the TransformationReader
  virtual TransformationReader<ReformatBaseStream>& transformationReader() {
    return reader;
  }


 protected:
  TransformationReader<ReformatBaseStream> reader;
  Stream* p_io = nullptr;
  Print* p_out = nullptr;

  void setupReader() {
    if (getStream() != nullptr) {
      reader.begin(this, getStream());
    }
  }
};

/**
 * @brief Base class for Output Adpapters
 *
 */
class AudioOutputAdapter : public AudioOutput {};

/**
 * @brief Wrapper which converts a Print to a AudioOutput
 * @ingroup tools
 */
class AdapterPrintToAudioOutput : public AudioOutputAdapter {
 public:
  AdapterPrintToAudioOutput() = default;
  AdapterPrintToAudioOutput(Print& print) { setStream(print); }
  void setStream(Print& out) { p_print = &out; }
  void setAudioInfo(AudioInfo info) { cfg = info; }
  size_t write(const uint8_t* data, size_t len) {
    return p_print->write(data, len);
  }
  /// If true we need to release the related memory in the destructor
  virtual bool isDeletable() { return true; }

  AudioInfo audioInfo() { return cfg; }

 protected:
  Print* p_print = nullptr;
  AudioInfo cfg;
};

/**
 * @brief Wrapper which converts a AudioStream to a AudioOutput
 * @ingroup tools
 */
class AdapterAudioStreamToAudioOutput : public AudioOutputAdapter {
 public:
  AdapterAudioStreamToAudioOutput() = default;

  AdapterAudioStreamToAudioOutput(AudioStream& stream) { setStream(stream); }

  void setStream(AudioStream& stream) { p_stream = &stream; }

  void setAudioInfo(AudioInfo info) override {
    if (p_stream != nullptr) p_stream->setAudioInfo(info);
  }

  AudioInfo audioInfo() override {
    return p_stream != nullptr ? p_stream->audioInfo() : AudioInfo();
  }

  size_t write(const uint8_t* data, size_t len) override {
    return p_stream != nullptr ? p_stream->write(data, len) : 0;
  }

  int availableForWrite() override {
    return p_stream != nullptr ? p_stream->availableForWrite() : 0;
  }

  bool begin() override { return p_stream != nullptr && p_stream->begin(); }

  void end() override {
    if (p_stream != nullptr) p_stream->end();
  }

  /// If true we need to release the related memory in the destructor
  virtual bool isDeletable() override { return true; }

  operator bool() override { return p_stream != nullptr && *p_stream; }

 protected:
  AudioStream* p_stream = nullptr;
};

/**
 * @brief Wrapper which converts a AudioStream to a AudioOutput
 * @ingroup tools
 */
class AdapterAudioOutputToAudioStream : public AudioStream {
 public:
  AdapterAudioOutputToAudioStream() = default;

  AdapterAudioOutputToAudioStream(AudioOutput& stream) { setOutput(stream); }

  void setOutput(AudioOutput& stream) { p_stream = &stream; }

  void setAudioInfo(AudioInfo info) override {
    if (p_stream != nullptr) p_stream->setAudioInfo(info);
  }

  AudioInfo audioInfo() override {
    return p_stream != nullptr ? p_stream->audioInfo() : AudioInfo();
  }

  size_t write(const uint8_t* data, size_t len) override {
    return p_stream != nullptr ? p_stream->write(data, len) : 0;
  }

  bool begin() override { return p_stream != nullptr && p_stream->begin(); }

  void end() override {
    if (p_stream != nullptr) p_stream->end();
  }

  /// If true we need to release the related memory in the destructor
  virtual bool isDeletable() { return true; }

  operator bool() override { return p_stream != nullptr && *p_stream; }

 protected:
  AudioOutput* p_stream = nullptr;
};

/**
 * @brief Replicates the output to multiple destinations.
 * @ingroup transform
 * @author Phil Schatzmann
 * @copyright GPLv3
 */
class MultiOutput : public ModifyingOutput {
 public:
  /// Defines a MultiOutput with no final output: Define your outputs with add()
  MultiOutput() = default;

  MultiOutput(Print& out) { add(out); }

  /// Defines a MultiOutput with a single final outputs,
  MultiOutput(AudioOutput& out) { add(out); }

  MultiOutput(AudioStream& out) { add(out); }

  /// Defines a MultiOutput with 2 final outputs
  MultiOutput(AudioOutput& out1, AudioOutput& out2) {
    add(out1);
    add(out2);
  }

  /// Defines a MultiOutput with 2 final outputs
  MultiOutput(AudioStream& out1, AudioStream& out2) {
    add(out1);
    add(out2);
  }

  /// Defines a MultiOutput with 2 final outputs: Warning no support for
  /// AudioInfo notifications. It is recommended to use individual add calls.
  MultiOutput(Print& out1, Print& out2) {
    add(out1);
    add(out2);
  }

  virtual ~MultiOutput() { clear(); }

  /// Add an additional AudioOutput output
  void add(AudioOutput& out) {
    vector.push_back({&out, &out, Kind::AudioOutputKind});
  }

  /// Add an AudioStream to the output
  void add(AudioStream& stream) {
    vector.push_back({&stream, &stream, Kind::AudioStreamKind});
  }

  /// Add a (network) Client as output: e.g. WiFiClient, EthernetClient...
  void add(Client& client) {
    vector.push_back({&client, nullptr, Kind::ClientKind});
  }

  /// Add a generic Print output: Warning no support for AudioInfo
  /// notifications. It is recommended to use one of the other add() methods.
  void add(Print& print) { vector.push_back({&print, nullptr, Kind::PrintKind}); }

  /// Removes the indicated output
  void remove(Print& print) {
    for (int j = 0; j < vector.size(); j++) {
      if (vector[j].print == &print) {
        vector.erase(j);
        return;
      }
    }
  }

  void flush() {
    for (int j = 0; j < vector.size(); j++) {
      vector[j].print->flush();
    }
  }

  void setAudioInfo(AudioInfo info) {
    for (int j = 0; j < vector.size(); j++) {
      if (vector[j].info != nullptr) {
        vector[j].info->setAudioInfo(info);
      }
    }
  }

  size_t write(const uint8_t* data, size_t len) override {
    for (auto& rec : vector) {
      int open = len;
      int start = 0;
      // create copy of data to avoid that one output changes the data for the
      // other outputs
      uint8_t copy[len];
      memcpy(copy, data, len);
      while (open > 0) {
        int written = rec.print->write(copy + start, open);
        open -= written;
        start += written;
      }
    }
    return len;
  }

  size_t write(uint8_t ch) override {
    for (int j = 0; j < vector.size(); j++) {
      int open = 1;
      while (open > 0) {
        open -= vector[j].print->write(ch);
      }
    }
    return 1;
  }

  /// Removes all output components: the referenced Print/AudioOutput/
  /// AudioStream/Client objects are never owned by MultiOutput, so no
  /// memory needs to be released here.
  void clear() { vector.clear(); }

  /// Removes all outputs which are no longer active. Client, AudioStream and
  /// AudioOutput provide an operator bool() which is used to determine if the
  /// output is still active; plain Print outputs cannot be checked and are
  /// always kept.
  void clearInactive() {
    for (int j = vector.size() - 1; j >= 0; j--) {
      if (!isActive(vector[j])) {
        vector.erase(j);
      }
    }
  }

 protected:
  /// Identifies the actual type behind the stored Print pointer so that
  /// clearInactive() can safely static_cast back to call operator bool()
  enum class Kind { PrintKind, ClientKind, AudioStreamKind, AudioOutputKind };

  /// Record describing a single replicated output
  struct MultiOutputRecord {
    /// Target to which the data is actually written
    Print* print;
    /// Optional AudioInfoSupport interface: only set when the added object
    /// also supports AudioInfo notifications (AudioOutput, AudioStream)
    AudioInfoSupport* info;
    /// Actual type of the object behind print
    Kind kind;

    MultiOutputRecord(Print* print = nullptr, AudioInfoSupport* info = nullptr,
                       Kind kind = Kind::PrintKind)
        : print(print), info(info), kind(kind) {}
  };

  Vector<MultiOutputRecord> vector;

  /// Determines if the output is still active: Client, AudioStream and
  /// AudioOutput support this via their operator bool(); plain Print
  /// outputs cannot be checked and are always reported as active.
  bool isActive(MultiOutputRecord& rec) {
    switch (rec.kind) {
      case Kind::ClientKind:
        return (bool)*static_cast<Client*>(rec.print);
      case Kind::AudioStreamKind:
        return (bool)*static_cast<AudioStream*>(rec.print);
      case Kind::AudioOutputKind:
        return (bool)*static_cast<AudioOutput*>(rec.print);
      default:
        return true;
    }
  }

  /// support for Pipleline
  void setOutput(Print& out) { add(out); }
};

/**
 * @brief AudioStream class that can define a start and (an optional) stop time
 * Usually it is used to wrap an Audio Sink (e.g. I2SStream), but wrapping an
 * Audio Source is supported as well. Only wrap classes which represent PCM
 * data!
 * @ingroup transform
 * @author Phil Schatzmann
 * @copyright GPLv3
 */
class TimedStream : public ModifyingStream {
 public:
  TimedStream() = default;

  TimedStream(AudioStream& io, long startSeconds = 0, long endSeconds = -1) {
    p_io = &io;
    p_out = &io;
    p_info = &io;
    setStartSec(startSeconds);
    setEndSec(endSeconds);
  }

  TimedStream(AudioOutput& o, long startSeconds = 0, long endSeconds = -1) {
    p_out = &o;
    p_info = &o;
    setStartSec(startSeconds);
    setEndSec(endSeconds);
  }

  TimedStream(Stream& io, long startSeconds = 0, long endSeconds = -1) {
    p_io = &io;
    p_out = &io;
    setStartSec(startSeconds);
    setEndSec(endSeconds);
  }

  TimedStream(Print& o, long startSeconds = 0, long endSeconds = -1) {
    p_out = &o;
    setStartSec(startSeconds);
    setEndSec(endSeconds);
  }

  /// Defines the start time in seconds. The audio before the start time will be
  /// skipped
  void setStartSec(uint32_t startSeconds) {
    start_ms = startSeconds * 1000;
    calculateByteLimits();
  }

  /// Defines the start time in milliseconds
  void setStartMs(uint32_t ms) {
    start_ms = ms;
    calculateByteLimits();
  }

  /// Defines (an optional) the end time in seconds. After the end time no audio
  /// is played and available() will return 0
  void setEndSec(uint32_t endSeconds) {
    end_ms = endSeconds * 1000;
    calculateByteLimits();
  }

  /// Defines the (optional) end time in milliseconds
  void setEndMs(uint32_t ms) {
    end_ms = ms;
    calculateByteLimits();
  }

  /// Returns true if we are in a valid time range and are still playing sound
  bool isPlaying() {
    if (current_bytes < start_bytes) return false;
    if (end_bytes > 0 && current_bytes > end_bytes) return false;
    return true;
  }

  /// Returns true if we are not past the end time;
  bool isActive() {
    return (current_bytes < end_bytes && current_bytes >= start_bytes);
  }

  bool begin(AudioInfo info) {
    setAudioInfo(info);
    return begin();
  }

  bool begin() override {
    calculateByteLimits();
    current_bytes = 0;
    LOGI("byte range %u - %u", (unsigned)start_bytes, (unsigned)end_bytes);
    return true;
  }

  operator bool() override { return isActive(); }

  /// Provides only data for the indicated start and end time. Only supported
  /// for data which does not contain any heder information: so PCM, mp3 should
  /// work!
  size_t readBytes(uint8_t* data, size_t len) override {
    // if reading is not supported we stop
    if (p_io == nullptr) return 0;
    // Positioin to start
    if (start_bytes > current_bytes) {
      consumeBytes(start_bytes - current_bytes);
    }
    // if we are past the end we stop
    if (!isActive()) return 0;
    // read the data now
    size_t result = 0;
    do {
      result = p_io->readBytes(data, len);
      current_bytes += len;
      // ignore data before start time
    } while (result > 0 && current_bytes < start_bytes);
    return isPlaying() ? result : 0;
  }

  /// Plays only data for the indiated start and end time
  size_t write(const uint8_t* data, size_t len) override {
    if (current_bytes >= end_bytes) return 0;
    current_bytes += len;
    if (current_bytes < start_bytes) return len;
    return p_out->write(data, len);
  }

  /// Provides the available bytes until the end time has reached
  int available() override {
    if (p_io == nullptr) return 0;
    return current_bytes < end_bytes ? p_io->available() : 0;
  }

  /// Updates the AudioInfo in the current object and in the source or target
  void setAudioInfo(AudioInfo info) override {
    AudioStream::setAudioInfo(info);
    if (p_info) p_info->setAudioInfo(info);
    calculateByteLimits();
  }

  int availableForWrite() override {
    return current_bytes < end_bytes ? p_out->availableForWrite() : 0;
  }

  void flush() override {
    if (p_out != nullptr) p_out->flush();
  }

  /// Experimental: if used on mp3 you can set the compression ratio e.g. to 11
  /// which will be used to approximate the time
  void setCompressionRatio(float ratio) { compression_ratio = ratio; }

  /// Calculates the bytes per second from the AudioInfo
  int bytesPerSecond() {
    return info.sample_rate * info.channels * info.bits_per_sample / 8;
  }

  void setOutput(Print& out) override { p_out = &out; }

  void setStream(Stream& stream) override {
    p_out = &stream;
    p_io = &stream;
  }

  void setOutput(AudioOutput& out) {
    p_out = &out;
    p_info = &out;
  }

  void setStream(AudioOutput& out) {
    p_out = &out;
    p_info = &out;
  }

  void setStream(AudioStream& stream) {
    p_out = &stream;
    p_io = &stream;
    p_info = &stream;
  }

  size_t size() { return end_bytes - start_bytes; }

 protected:
  Stream* p_io = nullptr;
  Print* p_out = nullptr;
  AudioInfoSupport* p_info = nullptr;
  uint32_t start_ms = 0;
  uint32_t end_ms = UINT32_MAX;
  uint32_t start_bytes = 0;
  uint32_t end_bytes = UINT32_MAX;
  uint32_t current_bytes = 0;
  float compression_ratio = 1.0;

  void consumeBytes(uint32_t len) {
    int open = len;
    uint8_t buffer[1024];
    while (open > 0) {
      int toread = min(1024, open);
      p_io->readBytes(buffer, toread);
      open -= toread;
    }
    current_bytes += len;
    LOGD("consumed %u -> %u", (unsigned)len, (unsigned)current_bytes);
  }

  void calculateByteLimits() {
    float bytes_per_second = bytesPerSecond();
    if (bytes_per_second > 0) {
      start_bytes = bytes_per_second * start_ms / compression_ratio / 1000;
      end_bytes = bytes_per_second * end_ms / compression_ratio / 1000;
    } else {
      LOGE("AudioInfo not defined");
    }
  }
};

/**
 * @brief Flexible functionality to extract one or more channels from a
 * multichannel signal. Warning: the destinatios added with addOutput
 * are not automatically notified about audio changes.
 * @ingroup transform
 * @author Phil Schatzmann
 * @copyright GPLv3
 * @tparam T
 */
class ChannelsSelectOutput : public AudioOutput {
 public:
  ChannelsSelectOutput() = default;

  bool begin(AudioInfo info) override {
    setAudioInfo(info);
    return begin();
  }

  bool begin() override {
    AudioOutput::begin();
    // make sure that selected channels are valid
    for (auto& out : out_channels) {
      for (auto& ch : out.channels) {
        if (ch > cfg.channels - 1) {
          LOGE("Channel '%d' not valid for max %d channels", ch, cfg.channels);
          return false;
        }
      }
    }
    return true;
  }

  /// Define the channel to be selected to the specified output. 0: first
  /// (=left) channel, 1: second (=right) channel
  void addOutput(AudioOutput& out, uint16_t channel) {
    Vector<uint16_t> channels;
    channels.push_back(channel);
    ChannelSelectionOutputDef def;
    def.channels = channels;
    def.p_out = &out;
    def.p_audio_info = &out;
    out_channels.push_back(def);
  }

  /// Define the channel to be selected to the specified output. 0: first
  /// (=left) channel, 1: second (=right) channel
  void addOutput(AudioStream& out, uint16_t channel) {
    Vector<uint16_t> channels;
    channels.push_back(channel);
    ChannelSelectionOutputDef def;
    def.channels = channels;
    def.p_out = &out;
    def.p_audio_info = &out;
    out_channels.push_back(def);
  }

  /// Define the channel to be selected to the specified output. 0: first
  /// (=left) channel, 1: second (=right) channel
  void addOutput(Print& out, uint16_t channel) {
    Vector<uint16_t> channels;
    channels.push_back(channel);
    ChannelSelectionOutputDef def;
    def.channels = channels;
    def.p_out = &out;
    out_channels.push_back(def);
  }

  /// Define the stereo channels to be selected to the specified output. 0:
  /// first (=left) channel, 1: second (=right) channel
  void addOutput(Print& out, uint16_t left, uint16_t right) {
    Vector<uint16_t> channels;
    channels.push_back(left);
    channels.push_back(right);
    ChannelSelectionOutputDef def;
    def.channels = channels;
    def.p_out = &out;
    out_channels.push_back(def);
  }

  /// Define the stereo channels to be selected to the specified output. 0:
  /// first (=left) channel, 1: second (=right) channel
  void addOutput(AudioOutput& out, uint16_t left, uint16_t right) {
    Vector<uint16_t> channels;
    channels.push_back(left);
    channels.push_back(right);
    ChannelSelectionOutputDef def;
    def.channels = channels;
    def.p_out = &out;
    def.p_audio_info = &out;
    out_channels.push_back(def);
  }

  /// Define the stereo channels to be selected to the specified output. 0:
  /// first (=left) channel, 1: second (=right) channel
  void addOutput(AudioStream& out, uint16_t left, uint16_t right) {
    Vector<uint16_t> channels;
    channels.push_back(left);
    channels.push_back(right);
    ChannelSelectionOutputDef def;
    def.channels = channels;
    def.p_out = &out;
    def.p_audio_info = &out;
    out_channels.push_back(def);
  }

  size_t write(const uint8_t* data, size_t len) override {
    if (!is_active) return false;
    LOGD("write %d", (int)len);
    switch (cfg.bits_per_sample) {
      case 16:
        return writeT<int16_t>(data, len);
      case 24:
        return writeT<int24_t>(data, len);
      case 32:
        return writeT<int32_t>(data, len);
      default:
        return 0;
    }
  }

  void setAudioInfo(AudioInfo ai) override {
    this->cfg = ai;
    // notifyAudioChange(ai);
    for (auto& info : out_channels) {
      auto p_notify = info.p_audio_info;
      if (p_notify != nullptr) {
        AudioInfo result{ai};
        result.channels = info.channels.size();
        p_notify->setAudioInfo(result);
      }
    }
  }

 protected:
  struct ChannelSelectionOutputDef {
    Print* p_out = nullptr;
    AudioInfoSupport* p_audio_info = nullptr;
    SingleBuffer<uint8_t> buffer{CHANNEL_SELECT_BUFFER_SIZE};
    Vector<uint16_t> channels{0};
  };
  Vector<ChannelSelectionOutputDef> out_channels{0};

  template <typename T>
  size_t writeT(const uint8_t* buffer, size_t size) {
    if (!is_active) return 0;
    int sample_count = size / sizeof(T);
    // int result_size = sample_count / cfg.channels;
    T* data = (T*)buffer;

    for (int i = 0; i < sample_count; i += cfg.channels) {
      T* frame = data + i;
      for (auto& out : out_channels) {
        T out_frame[out.channels.size()];
        int ch_out = 0;
        for (auto& ch : out.channels) {
          // make sure we have a valid channel
          int channel = (ch < cfg.channels) ? ch : cfg.channels - 1;
          out_frame[ch_out++] = frame[channel];
        }
        // write to buffer
        size_t written = out.buffer.writeArray((const uint8_t*)&out_frame,
                                               sizeof(out_frame));
        // write buffer to final output
        if (out.buffer.availableForWrite() < sizeof(out_frame)) {
          out.p_out->write(out.buffer.data(), out.buffer.available());
          out.buffer.reset();
        }
        // if (written != sizeof(out_frame)) {
        //   LOGW("Could not write all samples %d -> %d", sizeof(out_frame),
        //   written);
        // }
      }
    }
    return size;
  }

  /// Determine number of channels for destination
  int getChannels(Print* out, int defaultChannels) {
    for (auto& channels_select : out_channels) {
      if (channels_select.p_out == out) return channels_select.channels.size();
    }
    return defaultChannels;
  }
};

/**
 * @brief AudioTimeSourceStream: A stream that provides time information
 * based on the audio data actually processed - implements the TimeSource
 * interface. millis() (inherited, unmodified) is plain wall time;
 * playbackTime() is the audio-derived progress, which is what a consumer
 * that must stay tied to genuine playback (e.g. PacedVideoOutput) should
 * use instead - see playbackTime()'s own comment for why they can diverge.
 * @ingroup io
 * @author Phil Schatzmann
 */

class AudioTimeSourceStream : public AudioStream, public TimeSource {
 public:
  AudioTimeSourceStream() = default;
  AudioTimeSourceStream(AudioStream& stream) { setStream(stream); }
  AudioTimeSourceStream(AudioOutput& out)  { setOutput(out); }
  AudioTimeSourceStream(Print& print)  { setOutput(print); }
  AudioTimeSourceStream(Stream& stream) { setStream(stream); }

  /// Optional: explicitly (re)starts playbackTime() at 0 - use this if
  /// you need an explicit restart point (e.g. looping/seeking). Not
  /// required otherwise: the first byte that actually flows through
  /// write()/readBytes() anchors it on its own (see updateTime()) - most
  /// callers just wire this in as a plain Print/AudioStream target (e.g.
  /// PacedVideoOutput::setAudioClock()'s usage pattern) and never call
  /// begin() on it directly.
  bool begin() {
    bool result = AudioStream::begin();
    if (result) {
      resetTime();
    }
    return result;
  }

  size_t readBytes(uint8_t* data, size_t len) override {
    if (time_callback_before != nullptr) {
      time_callback_before(playbackTime());
    }
    // Forward to the configured source (set via setStream()) rather than
    // AudioStream::readBytes(), which is just an "unsupported" stub with
    // no knowledge of p_stream.
    size_t result = p_stream != nullptr ? p_stream->readBytes(data, len) : 0;
    if (result > 0) {
      updateTime(result);
    }
    return result;
  }

  size_t write(const uint8_t* data, size_t len) override {
    if (time_callback_before != nullptr) {
      time_callback_before(playbackTime());
    }
    // Forward to the configured target (set via setOutput()/setStream())
    // rather than AudioStream::write(), which is just an "unsupported"
    // stub with no knowledge of p_out - this class exists specifically to
    // sit transparently between a decoder and the real audio sink.
    size_t result = p_out != nullptr ? p_out->write(data, len) : 0;
    if (result > 0) {
      updateTime(result);
    }
    return result;
  }

  /// Elapsed playback time (ms): the sum of audio duration
  /// (sample_rate/channels/bits_per_sample-derived) actually handed to
  /// write()/readBytes() so far - see TimeSource::playbackTime(). Purely
  /// a running total of processed bytes: never extrapolated by, or
  /// otherwise dependent on, wall-clock time (see millis(), inherited
  /// unmodified, for that) - so it stalls exactly when the caller stalls
  /// (e.g. busy elsewhere in a shared demux/decode loop) instead of
  /// continuing to advance. Returns 0 before the first byte has ever been
  /// processed (begin() is optional - see its own comment).
  uint32_t playbackTime() override { return playback_time_ms; }

  void setOutput(Print& out)  {
    p_out = &out;
  }
  void setOutput(AudioOutput& out)  {
    p_out = &out;
    addNotifyAudioChange(out);
  }
  void setStream(Stream& stream)  {
    p_stream = &stream;
    p_out = &stream;
  }
  void setStream(AudioStream& stream)  {
    p_stream = &stream;
    p_out = &stream;
    addNotifyAudioChange(stream);
  }
  /// Defines a callback function to be called whenever the time is updated
  void setTimeCallback(void (*cb)(uint32_t time_ms)) { time_callback_before = cb; }
  /// Defines a callback function to be called whenever the time is updated
  void setTimeCallbackAfter(void (*cb)(uint32_t time_ms)) { time_callback_after = cb; }

 protected:
  Print *p_out = nullptr;
  Stream *p_stream = nullptr;
  // Pure running total of byte-derived durations - see playbackTime().
  // Never touched by wall-clock time.
  uint32_t playback_time_ms = 0;
  void (*time_callback_before)(uint32_t time_ms) = nullptr;
  void (*time_callback_after)(uint32_t time_ms) = nullptr;

  void resetTime() { playback_time_ms = 0; }

  void updateTime(size_t bytes) {
    AudioInfo info = audioInfo();
    uint32_t bytes_per_second = info.sample_rate * info.channels * info.bits_per_sample / 8;
    if (bytes_per_second == 0) return;
    uint32_t added_ms = (uint32_t)(((uint64_t)bytes * 1000) / bytes_per_second);
    playback_time_ms += added_ms;
    if (time_callback_after != nullptr) {
      time_callback_after(playback_time_ms);
    }
  }
};


}  // namespace audio_tools
