#pragma once

#include "AudioTools/CoreAudio/AudioTypes.h"
#include "AudioTools/CoreAudio/Buffers.h"
#include "AudioTools/CoreAudio/BaseConverter.h"
#include "AudioTools/CoreAudio/AudioLogger.h"
#include "AudioTools/CoreAudio/AudioStreams.h"
#include "AudioTools/CoreAudio/AudioStreamsConverter.h"
#include "AudioTools/CoreAudio/AudioOutput.h"
#include "AudioTools/CoreAudio/AudioIO.h"
#include "AudioTools/CoreAudio/ResampleStream.h"
#include "AudioTools/CoreAudio/ResampleStreamT.h"
#include "AudioTools/CoreAudio/SupportedRatesStream.h"
#include "AudioTools/CoreAudio/StreamCopy.h"
#include "AudioTools/CoreAudio/MusicalNotes.h"
#include "AudioTools/CoreAudio/Fade.h"
#include "AudioTools/CoreAudio/Pipeline.h"
#include "AudioTools/CoreAudio/AudioPlayer.h"
#include "AudioTools/CoreAudio/AudioTimer.h"
#include "AudioTools/CoreAudio/AudioFilter.h"
#include "AudioTools/CoreAudio/I2SStream.h"
#include "AudioTools/CoreAudio/AudioPWM/PWMAudioOutput.h"
#include "AudioTools/CoreAudio/AnalogAudioStream.h"
#include "AudioTools/CoreAudio/AudioEffects.h"
#include "AudioTools/CoreAudio/AudioMetaData.h"
#include "AudioTools/CoreAudio/Analysis.h"
#include "AudioTools/CoreAudio/RTTTLOutput.h"
#include "AudioTools/CoreAudio/AudioBasic/Str.h"
#include "AudioTools/CoreAudio/AudioBasic/Format.h"

// Audio Actions only when pin support havs been defined
#if defined(GPIO_NONE)
#include "AudioTools/CoreAudio/AudioActions.h"
#endif
